import sys

from models import TimeInterval
from utils.config import BUFFER_TIMES, MEETING_ROOMS
from services import MeetingScheduler
from utils.exceptions import IncorrectInputError

from utils.constants import InputType, Output


class Driver:

    @staticmethod
    def process_line(line: str):
        line = line.strip()
        if line.startswith(InputType.BOOK):
            _, start, end, capacity = line.split()
            out = Driver.book_room(start, end, int(capacity))
            print(out)
        if line.startswith(InputType.VACANCY):
            _, start, end = line.split()
            out = Driver.vacancy(start, end)
            print(out)

    @staticmethod
    def book_room(start_time: str, end_time: str, capacity: int) -> str:
        service = MeetingScheduler.get_instance()
        try:
            time_interval = TimeInterval(start_time, end_time)
            room = service.book_room(time_interval, capacity)
            if room:
                return room.name
            return Output.NO_VACANT_ROOM
        except IncorrectInputError:
            return Output.INCORRECT_INPUT

    @staticmethod
    def vacancy(start_time: str, end_time: str) -> str:
        service = MeetingScheduler.get_instance()
        try:
            time_interval = TimeInterval(start_time, end_time)
            room_list = service.get_vacancies(time_interval)
            if not room_list:
                return Output.NO_VACANT_ROOM
            return " ".join([room.name for room in room_list])
        except IncorrectInputError:
            return Output.INCORRECT_INPUT


def main():
    input_file = sys.argv[1]

    # Singleton, returns same instance
    MeetingScheduler.create_instance(MEETING_ROOMS, BUFFER_TIMES)

    with open(input_file, 'r+') as f:
        for line in f.readlines():
            Driver.process_line(line)


if __name__ == "__main__":
    main()

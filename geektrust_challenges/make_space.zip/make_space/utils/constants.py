class InputType:
    BOOK = 'BOOK'
    VACANCY = 'VACANCY'


class Output:
    INCORRECT_INPUT = 'INCORRECT_INPUT'
    NO_VACANT_ROOM = 'NO_VACANT_ROOM'

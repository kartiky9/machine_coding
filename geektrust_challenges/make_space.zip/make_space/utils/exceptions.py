class IncorrectInputError(Exception):
    pass
